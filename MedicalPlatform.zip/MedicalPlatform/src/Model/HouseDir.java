/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class HouseDir {
    static ArrayList<House> Housedir;
    
    public HouseDir() {
		HouseDir.Housedir=new ArrayList<House>();
	}
	public ArrayList<House> getList(){
		return Housedir;	
	}
        
	public void setList(ArrayList<House>Housedir) {
		HouseDir.Housedir=Housedir;
        }
        
        public House addnew(){
            House newh= new House();
            Housedir.add(newh);
            return newh;
        }
        
        public void deletehos(House newh){
            Housedir.remove(newh);
        }
    
}
