/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author anamikabharali
 */
public class Encounter {
    private String Diagnosis;
    private String Date;
    private int Doctorid;
    private int Patientid;
    private int encid;

    public String getDiagnosis() {
        return Diagnosis;
    }

    public void setDiagnosis(String Diagnosis) {
        this.Diagnosis = Diagnosis;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public int getDoctorid() {
        return Doctorid;
    }

    public void setDoctorid(int Doctorid) {
        this.Doctorid = Doctorid;
    }

    public int getPatientid() {
        return Patientid;
    }

    public void setPatientid(int Patientid) {
        this.Patientid = Patientid;
    }

    public int getEncid() {
        return encid;
    }

    public void setEncid(int encid) {
        this.encid = encid;
    }
    
}
