/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class CommDir {
    static ArrayList<Community> Commdir;
    
    public CommDir() {
		CommDir.Commdir=new ArrayList<Community>();
	}
	public ArrayList<Community> getList(){
		return Commdir;	
	}
        
	public void setList(ArrayList<Community>Commdir) {
		CommDir.Commdir=Commdir;
        }
        
        public Community addnew(){
            Community newCommunity= new Community();
            Commdir.add(newCommunity);
            return newCommunity;
        }
        
        public void deleteList(Community newCommunity){
            Commdir.remove(newCommunity);
        }
}
