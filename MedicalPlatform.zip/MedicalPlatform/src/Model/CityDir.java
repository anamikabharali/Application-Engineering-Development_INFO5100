/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class CityDir {
    
    static ArrayList<City> Citydir;
    
    public CityDir() {
		CityDir.Citydir=new ArrayList<City>();
	}
	public ArrayList<City> getList(){
		return Citydir;	
	}
        
	public void setList(ArrayList<City>Citydir) {
		CityDir.Citydir=Citydir;
        }
        
        public City addnew(){
            City newCity= new City();
            Citydir.add(newCity);
            return newCity;
        }
        
        public void deletecity(City newCity){
            Citydir.remove(newCity);
        }
    
}
