/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

/**
 *
 * @author anamikabharali
 */
public class Patient extends Person{
    private boolean ispatient;
    private int patientid;

    public int getPatientid() {
        return patientid;
    }

    public void setPatientid(int patientid) {
        this.patientid = patientid;
    }

    public boolean Ispatient() {
        return ispatient;
    }

    public void setIspatient(boolean ispatient) {
        this.ispatient = ispatient;
    }
    
}
