/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class HospitalDir {
    
    ArrayList storedHos=new ArrayList<Hospital>();
    
    public HospitalDir() {
		storedHos=new ArrayList<Hospital>();
		
	}
        
        public ArrayList<Hospital> getList(){
		return storedHos;	
	}
        
	public void setList(ArrayList<Hospital>storedHos) {
		this.storedHos=storedHos;
        }
        
        public Hospital addnew(){
            Hospital newhospital= new Hospital();
            storedHos.add(newhospital);
            return newhospital;
        }
        
        public void deletehos(Hospital newhospital){
            storedHos.remove(newhospital);
        }
        public void deletehospital(int index){
            storedHos.remove(index);
        }

        
}
