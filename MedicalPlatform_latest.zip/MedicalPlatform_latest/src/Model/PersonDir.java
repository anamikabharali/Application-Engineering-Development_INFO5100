/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class PersonDir {
    
    public ArrayList storedPersons=new ArrayList<Person>();
    
    public PersonDir() {
		storedPersons=new ArrayList<Person>();
	}
	public ArrayList<Person> getList(){
		return storedPersons;	
	}
        
	public void setList(ArrayList<Person>storedPersons) {
		this.storedPersons=storedPersons;
        }
        
        public Person addnew(){
            Person newPerson= new Person();
            storedPersons.add(newPerson);
            return newPerson;
        }
        
        public void deleteList(Person newPerson){
            storedPersons.remove(newPerson);
        }
        public void deleteList2(int newP){
            storedPersons.remove(newP);
        }
    
}
