/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anamikabharali
 */
public class PatientDir {
    List<Patient> storedPatients;
    
    public PatientDir() {
		this.storedPatients=new ArrayList<>();
	}
	public List<Patient> getList(){
		return this.storedPatients;	
	}
        
	public void setList(ArrayList<Patient>storedPatients) {
		this.storedPatients=storedPatients;
        }
        
        public Patient addnew(){
            Patient newPatient= new Patient();
            storedPatients.add(newPatient);
            return newPatient;
        }
        
        public void deleteList(Patient newPatient){
            storedPatients.remove(newPatient);
        }
        public void deleteList2(int newq){
            storedPatients.remove(newq);
        }
}
