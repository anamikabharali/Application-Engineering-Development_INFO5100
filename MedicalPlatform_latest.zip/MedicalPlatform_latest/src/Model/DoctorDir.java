/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class DoctorDir {
    
    ArrayList storedDoctors=new ArrayList<Doctor>();
    
    public DoctorDir() {
		storedDoctors=new ArrayList<Doctor>();
	}
	public ArrayList<Doctor> getList(){
		return storedDoctors;	
	}
        
	public void setList(ArrayList<Doctor>storedDoctors) {
		this.storedDoctors=storedDoctors;
        }
        
        public Doctor addnew(){
            Doctor newdoctor= new Doctor();
            storedDoctors.add(newdoctor);
            return newdoctor;
        }
        
        

    public void deleteDoc(Doctor ddnew) {
        storedDoctors.remove(ddnew);
    }
    public void deleteDoc2(int ddnew) {
        storedDoctors.remove(ddnew);
    }
        
}
