/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class EncounterDir {
    
    ArrayList storedEncounters=new ArrayList<Vitalsigns>();
    
    public EncounterDir() {
		storedEncounters=new ArrayList<Vitalsigns>();
	}
	public ArrayList<Vitalsigns> getList(){
		return storedEncounters;	
	}
        
	public void setList(ArrayList<Vitalsigns>storedEncounters) {
		//this.storedEncounters=this.storedEncounters;
                this.storedEncounters=storedEncounters;
        }
        
        public Vitalsigns addnew(Vitalsigns newencounter){
            //Vitalsigns newencounter= new Vitalsigns();
            storedEncounters.add(newencounter);
            return newencounter;
        }
        
        public void deleteList(Vitalsigns newencounter){
            
            storedEncounters.remove(newencounter);
        }
        public void deleteList2(int ter){
            
            storedEncounters.remove(ter);
        }
        
//        public Vitalsigns addNewVitals(){
//            
//        Vitalsigns newvitals = new Vitalsigns();
//        storedEncounters.add(newvitals);
//        return newvitals;
  //  }
}
