/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class City {
    
    private String name;
    public ArrayList<Hospital> hosInCity;

    public String getCityname() {
        return name;
    }

    public void setCityName(String name) {
        this.name = name;
    }
    public ArrayList<Hospital> gethosInCity() {
        return hosInCity;
    }

    public void sethosInCity(ArrayList housesInCommunity) {
        this.hosInCity = housesInCommunity;
    }

    public City(String name) {
        this.name = name;
        hosInCity = new ArrayList<Hospital>();
    }
    public City() {
        hosInCity = new ArrayList<Hospital>();
    }
    
}
