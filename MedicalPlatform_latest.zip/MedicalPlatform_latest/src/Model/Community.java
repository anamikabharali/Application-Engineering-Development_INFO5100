/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class Community {
    
    private int pincode;
    public ArrayList<Hospital> hosInCommunity;
    public int getPincode() {
        return pincode;
    }

    public void setPincode(int pincode) {
        this.pincode = pincode;
    }
    public ArrayList<Hospital> getHosInCommunity() {
        return hosInCommunity;
    }

    public void setHosInCommunity(ArrayList housesInCommunity) {
        this.hosInCommunity = housesInCommunity;
    }

    public Community(int pincode) {
        this.pincode = pincode;
        hosInCommunity = new ArrayList<Hospital>();
    }
    public Community() {
        hosInCommunity = new ArrayList<Hospital>();
    }
   
}
