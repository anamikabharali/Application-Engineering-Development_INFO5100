/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class CityDir {
    
    ArrayList storedCities=new ArrayList<City>();
    
    public CityDir() {
		storedCities=new ArrayList<City>();
	}
	public ArrayList<City> getList(){
		return storedCities;	
	}
        
	public void setList(ArrayList<City>storedCities) {
		this.storedCities=storedCities;
        }
        
        public City addnew(){
            City newCity= new City();
            storedCities.add(newCity);
            return newCity;
        }
        
        public void deletecity(City newCity){
            storedCities.remove(newCity);
        }
        public void deletecity2(int index){
            storedCities.remove(index);}
}
