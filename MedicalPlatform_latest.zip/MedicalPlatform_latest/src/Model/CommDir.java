/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author anamikabharali
 */
public class CommDir {
    List<Community> storedCommunities;
    
    public CommDir() {
		storedCommunities=new ArrayList<>();
	}
	public List<Community> getList(){
		return this.storedCommunities;	
	}
        
	public void setList(ArrayList<Community> storedCommunities) {
		this.storedCommunities=storedCommunities;
        }
        
        public Community addnew(){
            Community newCommunity= new Community();
            storedCommunities.add(newCommunity);
            return newCommunity;
        }
        
        public void deleteList(Community newCommunity){
            storedCommunities.remove(newCommunity);
        }
        public void deleteList2(int newCommunity){
            storedCommunities.remove(newCommunity);
        }
}
