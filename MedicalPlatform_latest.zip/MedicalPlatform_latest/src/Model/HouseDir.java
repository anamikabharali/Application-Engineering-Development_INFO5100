/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.util.ArrayList;

/**
 *
 * @author anamikabharali
 */
public class HouseDir {
    
    ArrayList storedHouses=new ArrayList<House>();
    //static ArrayList<House> Housedir;
//    
//    public HouseDir() {
//		Housedir=new ArrayList<House>();
//	}
//	public ArrayList<House> getList(){
//		return Housedir;	
//	}
//        
//	public void setList(ArrayList<House>Housedir) {
//		HouseDir.Housedir=Housedir;
//        }
//        
//        public House addnew(){
//            House newh= new House();
//            Housedir.add(newh);
//            return newh;
//        }
//        
//        public void deletehouse(House newh){
//            Housedir.remove(newh);
//        }
//        public void deletehouse2(int newh){
//            Housedir.remove(newh);
//        }
//    
    
    public HouseDir() {
		storedHouses=new ArrayList<House>();
		
	}
        
        public ArrayList<House> getList(){
		return storedHouses;	
	}
        
	public void setList(ArrayList<House>storedHouses) {
		this.storedHouses=storedHouses;
        }
        
        public House addnew(){
            House newHouse= new House();
            storedHouses.add(newHouse);
            return newHouse;
        }
        
        public void deletehouse(House newHouse){
            storedHouses.remove(newHouse);
        }
        public void deletehouse2(int index){
            storedHouses.remove(index);
        }

        
}
